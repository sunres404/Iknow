package service.impl;

import bean.User;
import service.LoginService;

public class LoginServiceImpl implements LoginService {

	@Override
	public User loginUser(String name, String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
