package service.impl;

import bean.Page;
import service.MainService;

public class MainServiceImpl implements MainService {

	@Override
	public Page getEssayByEssaySeeCount(int nowPage) {
		// TODO Auto-generated method stub
		return null;
	}

}
