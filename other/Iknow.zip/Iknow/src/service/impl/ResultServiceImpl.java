package service.impl;


import bean.Page;
import service.ResultService;

public class ResultServiceImpl implements ResultService {

	@Override
	public Page getEssayByName(String name, int nowPage, int order) {
		// TODO Auto-generated method stub
		return null;
	}

}
