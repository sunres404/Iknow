package service.impl;


import bean.Page;
import service.KindService;

public class KindServiceImpl implements KindService {

	@Override
	public Page getEssayByKind(int kind, int nowPage, int order) {
		// TODO Auto-generated method stub
		return null;
	}

}
