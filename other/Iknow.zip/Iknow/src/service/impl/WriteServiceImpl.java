package service.impl;

import bean.Essay;
import service.WriteService;

public class WriteServiceImpl implements WriteService {

	@Override
	public Essay getEssayById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Essay addEssay(String essayName, String writerName,
			String essayContent, String otherInfo, int essayKind) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Essay updateEssay(int id, String essayName, String essayContent,
			String otherInfo, int essayKind) {
		// TODO Auto-generated method stub
		return null;
	}

}
