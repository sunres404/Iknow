package service.impl;

import bean.User;
import service.RegisterService;

public class RegisterServiceImpl implements RegisterService {

	@Override
	public boolean isExistUser(String name) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public User addUser(String name, String password, int kind) {
		// TODO Auto-generated method stub
		return null;
	}

}
